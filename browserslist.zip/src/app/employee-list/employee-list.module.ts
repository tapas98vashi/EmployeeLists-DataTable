import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { EmployeeListRoutingModule } from './employee-list-routing.module';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { EmployeeFormComponent } from './employee-form/employee-form.component';
import { DeleteEmployeeComponent } from './delete-employee/delete-employee.component';



@NgModule({
  declarations: [EmployeeListComponent, EmployeeFormComponent, DeleteEmployeeComponent],
  imports: [
    CommonModule,
    EmployeeListRoutingModule,
    ReactiveFormsModule
  ],
  exports: [
    EmployeeListComponent,
    DeleteEmployeeComponent
  ]
})
export class EmployeeListModule { }
