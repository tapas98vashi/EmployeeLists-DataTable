import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.scss']
})
export class EmployeeListComponent implements OnInit {

  lists: any = [];

  id = null;
  FullName = null;
  Email = null;
  Mobile = null;
  City = null;
  Department = null;

  empData = {}

  constructor(private httpClient: HttpClient) { }

  ngOnInit() {
    this.httpClient.get('http://localhost:3000/EmployeeData').subscribe(data => {
      console.log(data);
      this.lists = data;
    })
  }

}
