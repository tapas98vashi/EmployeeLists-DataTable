import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';

@Component({
  selector: 'app-employee-form',
  templateUrl: './employee-form.component.html',
  styleUrls: ['./employee-form.component.scss']
})
export class EmployeeFormComponent implements OnInit {

  profileForm = this.fb.group({
    fullname: ['', Validators.required],
    email: ['', Validators.required],
    mobile: ['', Validators.required],
    city: ['', Validators.required],
    gender: ['', Validators.required],
    department: ['', Validators.required],
    date: ['', Validators.required],
    permanentemp: ['', Validators.required],
  });

  onSubmit() {
    // TODO: Use EventEmitter with form value
    console.warn(this.profileForm.value);
  }

  constructor(private fb: FormBuilder) { }

  ngOnInit() {
  }

}
