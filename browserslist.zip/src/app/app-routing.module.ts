import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeFormComponent } from './employee-list/employee-form/employee-form.component';
import { DeleteEmployeeComponent } from './employee-list/delete-employee/delete-employee.component';


const routes: Routes = [
  {
    path: 'add',
    component: EmployeeFormComponent
},
{
    path: 'edit',
    component: EmployeeFormComponent
},
{
    path: 'delete/:id',
    component: DeleteEmployeeComponent
}
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
